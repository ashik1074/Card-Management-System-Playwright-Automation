export async function submitApplication(page) {
  //await page.getByRole('button', { name: 'Submit Application' }).click();
  await page.pause();
}
